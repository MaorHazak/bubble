package com.example.finalviocebubble;

import android.content.Context;
import android.media.AudioRecord;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Appdata {

    private static final Appdata ourInstance = new Appdata();

    public static Appdata getInstance() {
        return ourInstance;
    }

    public AudioRecord myRecord;
    public Thread mThread;
    public TextView textView;
    public Boolean fromBroadcast = false;
    public Context context;


    private Appdata() {

    }
}
