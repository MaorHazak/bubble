package com.example.finalviocebubble;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.anastr.speedviewlib.Gauge;
import com.github.anastr.speedviewlib.ImageSpeedometer;
import com.github.anastr.speedviewlib.SpeedView;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import pl.aprilapps.easyphotopicker.MediaFile;
import pl.aprilapps.easyphotopicker.MediaSource;


public class MainActivity extends AppCompatActivity {

    private static final int POLL_INTERVAL = 300;
    private Handler handler;
    public TextView textview;

    private AudioManager myAudioManager;
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;

    // Requesting permission to RECORD_AUDIO
    private boolean permissionToRecordAccepted = false;
    private String [] permissions = {Manifest.permission.RECORD_AUDIO};
    private static final int PERMISSION_RECORD_AUDIO = 0;
    Thread mThread;

    private MediaRecorder mRecorder = null;
    private Handler mHandler = new Handler();
    OnAudioDataListener onAudioDataListener;
    public static Gauge progressGauge;
    EditText rangeTxt;
    SeekBar seekBar;
    TextView percentageText;
    ImageSpeedometer imageSpeedometer;
    EasyImage easyImage;

    private Runnable mPollTask = new Runnable() {
        public void run() {
            Log.d("MainActivity","Poll : Amplitude : "+getAmplitude());


            ChatHeadService chatHeadService = new ChatHeadService();
            //chatHeadService.speedometer.speedTo(100);
            chatHeadService.setSpeedometer((int)getAmplitude());
            //Log.i("Noise", "runnable mPollTask");
            //updateDisplay(amp);
            onAudioDataListener.onAudioDataReceived((int)getAmplitude());

            // Runnable(mPollTask) will again execute after POLL_INTERVAL
            //mHandler.postDelayed(mPollTask, POLL_INTERVAL);
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode,  String[] permissions,  int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted  = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecordAccepted ) finish();

    }
    public void showWindowManager() {

        WindowManager.LayoutParams p =
                new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        Build.VERSION.SDK_INT > Build.VERSION_CODES.O
                                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                                : WindowManager.LayoutParams.TYPE_SYSTEM_ERROR,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSLUCENT);


        final WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater layoutInflater =
                (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
        final View popupView = layoutInflater.inflate(R.layout.buble_layout, null);
        textview = (TextView) popupView.findViewById(R.id.israel);
        //speedView = (SpeedView)popupView.findViewById(R.id.israel);

        windowManager.addView(popupView, p);


       /* mThread = new Thread(new Runnable() {
            @Override
            public void run() {
                record();
            }
        });*/
        mThread.start();
        // dismiss windowManager after 3s
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                windowManager.removeView(popupView);
            }
        }, 5000);
    }

    @Override
    protected void onStart() {
        super.onStart();
        try{
            String ext = getIntent().getStringExtra("fromser");
            Log.e("msgfromlistner",ext);
            rangeTxt.setText(String.valueOf(Utils.getRange(this)));
            if(ext.equalsIgnoreCase("1")){
                startBubbleAndAudio();
                finish();
            }
        }
        catch (Exception e){

        }

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Appdata.getInstance().context = this;
        progressGauge = findViewById(R.id.speedViewMain);

        imageSpeedometer = findViewById(R.id.imageSpeedometer);

        rangeTxt = findViewById(R.id.rangeText);
        percentageText = findViewById(R.id.percentTxt);
        seekBar = findViewById(R.id.seek_bar);
        int res = Utils.getProgress(MainActivity.this);
        seekBar.setMin(0);
        seekBar.setMax(22000);
        seekBar.setProgress(Utils.getRange(MainActivity.this));
        percentageText.setText(String.valueOf((int)res)+" %");
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                double res = ((double)progress / 22000.0f) * 100;

                percentageText.setText(String.valueOf((int)res)+" %");
                Utils.setProgress(MainActivity.this, (int)res);

                Log.d("TAG","progress ;"+progress);
                if(progress >5000) {
                    Utils.setRange(MainActivity.this, progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        rangeTxt.setText(String.valueOf(Utils.getRange(this)));
        ((findViewById(R.id.saveBtn))).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rangeTxt.getText().toString().equals("") || rangeTxt.getText().toString().isEmpty())
                    return;
                Utils.setRange(MainActivity.this,Integer.parseInt(rangeTxt.getText().toString()));
                ((findViewById(R.id.showbuble))).requestFocus();
                Toast.makeText(MainActivity.this, "Saved Range", Toast.LENGTH_SHORT).show();
            }
        });

        ((findViewById(R.id.selectView))).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                easyImage = new EasyImage.Builder(MainActivity.this)
                        .setCopyImagesToPublicGalleryFolder(false)
// Sets the name for images stored if setCopyImagesToPublicGalleryFolder = true
                        //.setFolderName("Voice Bubble")
                        .build();

                easyImage.openChooser(MainActivity.this);

            }
        });
       /* TelephonyManager telephony = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
        telephony.listen(new PhoneStateListener(){
            @Override
            public void onCallStateChanged(int state, String incomingNumber)
            {

                Log.e("Callstate",state+"");
                //  ((MainActivity)Appdata.getInstance().context).startBubbleAndAudio();
                if(state == TelephonyManager.CALL_STATE_OFFHOOK){
                    // Run the flash in that line
                    startBubbleAndAudio();
                }

            }
        },PhoneStateListener.LISTEN_CALL_STATE);*/
        (findViewById(R.id.showbuble)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // showWindowManager();
                if (Utils.canDrawOverlays(MainActivity.this)) {
                    startService(new Intent(MainActivity.this, ChatHeadService.class));
                    mThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            /*record();*/
                            /*start();
                            mHandler.postDelayed(mPollTask, POLL_INTERVAL);
                            Log.i(MainActivity.class.getName(),"getAmplitude() value: " + getAmplitude());*/
                        }
                    });
                    mThread.start();
                }else{
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, 101);
                }

            }
        });


        (findViewById(R.id.stopbuble)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // showWindowManager();
                /*if (Utils.canDrawOverlays(MainActivity.this)) {
                    startService(new Intent(MainActivity.this, ChatHeadServiceHide.class));
                    mThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            *//*record();*//*
                            stop();
                        }
                    });
                    mThread.start();
                }else{
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, 101);
                }

            }*/

                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        });

        if(Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 1234);
            }
        }
        else
        {
            Intent intent = new Intent(this, Service.class);
            startService(intent);
        }
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this,Manifest.permission.SYSTEM_ALERT_WINDOW) != PackageManager.PERMISSION_GRANTED){
         //   if (ActivityCompat.shouldShowRequestPermissionRationale(this,
           //         Manifest.permission.RECORD_AUDIO)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[] { Manifest.permission.RECORD_AUDIO,Manifest.permission.SYSTEM_ALERT_WINDOW },
                        PERMISSION_RECORD_AUDIO);
                return;
         //   } else {
                // No explanation needed; request the permission
              //  ActivityCompat.requestPermissions(this,
                //        new String[]{Manifest.permission.RECORD_AUDIO},
                  //      1);
              //  ActivityCompat.requestPermissions(this,
                //        new String[] { Manifest.permission.RECORD_AUDIO },
                   //     PERMISSION_RECORD_AUDIO);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
           // }
        }else{

            myAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
                String x = myAudioManager.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED);
            }

            runOnUiThread(()->{
                //speedView.speedTo(Integer.parseInt(x));

            });

        }

       // finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stop();
    }

    public void startBubbleAndAudio(){
    if (Utils.canDrawOverlays(MainActivity.this)) {
        startService(new Intent(MainActivity.this, ChatHeadService.class));
        mThread = new Thread(new Runnable() {
            @Override
            public void run() {
               /* record();*/
            }
        });
        mThread.start();
    }else{
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        intent.setData(Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, 101);
    }
}
    @Override
    protected void onDestroy() {
        super.onDestroy();
        stop();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101){

        }
        easyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onMediaFilesPicked(MediaFile[] imageFiles, MediaSource source) {
                //onPhotosReturned(imageFiles);

                Log.d("TAG","image L:"+ Arrays.toString(imageFiles));
                Log.d("TAG","image file :"+ imageFiles[0].getFile());
                Log.d("TAG","image Source:"+ source);

                File pathName = imageFiles[0].getFile();
                Drawable d = Drawable.createFromPath(String.valueOf(pathName));
                Bitmap bitmap = BitmapFactory.decodeFile(String.valueOf(pathName));

                //imageSpeedometer.setImageSpeedometer(getRoundedCroppedBitmap(bitmap));

                if(pathName != null){
                    Utils.setImagePath(MainActivity.this,String.valueOf(pathName));
                    Utils.setBubbleImage(MainActivity.this,true);
                }
                ChatHeadService.checkSpeedometerSelected(MainActivity.this);

            }

            @Override
            public void onImagePickerError(@NonNull Throwable error, @NonNull MediaSource source) {
                //Some error handling
                error.printStackTrace();
            }

            @Override
            public void onCanceled(@NonNull MediaSource source) {
                //Not necessary to remove any files manually anymore
            }
        });
    }

    public void start() {
        if (mRecorder == null) {
            mRecorder = new MediaRecorder();
            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mRecorder.setOutputFile("/dev/null");

            try {
                mRecorder.prepare();
            } catch (IOException e) {
                Log.e("MainActivity","Error : "+e.getLocalizedMessage());
                e.printStackTrace();
            }
            mRecorder.start();
            Log.d("MainActivity","Amplitude : "+getAmplitude());

            Log.i(MainActivity.class.getName(),"getAmplitude() value: " + getAmplitude());
        }
    }

    public void stop() {
        if (mRecorder != null) {
            mRecorder.stop();
            mRecorder.release();
            mRecorder = null;
        }
    }

    public double getAmplitude() {
        if (mRecorder != null)
            return  mRecorder.getMaxAmplitude();
        else
            return 0;

    }


}