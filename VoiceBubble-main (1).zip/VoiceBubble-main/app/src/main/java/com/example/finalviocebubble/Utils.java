package com.example.finalviocebubble;


import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.provider.Settings;
import android.speech.tts.UtteranceProgressListener;

public class Utils {
	public static String LogTag = "henrytest";
	public static String EXTRA_MSG = "extra_msg";
	public static  String PREF_ = "myPref";
	private static  SharedPreferences sharedPreferences;



	public static boolean canDrawOverlays(Context context){
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
			return true;
		}else{
			return Settings.canDrawOverlays(context);
		}


	}

	public static void setRange(Context context,int range){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		sharedPreferences.edit().putInt("range",range).apply();
	}
	public static int getRange(Context context){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		return sharedPreferences.getInt("range",10000);
	}
	public static void setProgress(Context context,int range){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		sharedPreferences.edit().putInt("progress",range).apply();
	}
	public static int getProgress(Context context){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		return sharedPreferences.getInt("progress",10);
	}
	public static void setBubbleImage(Context context,boolean isSet){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		sharedPreferences.edit().putBoolean("bubble",isSet).apply();
	}
	public static boolean getBubbleSet(Context context){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		return sharedPreferences.getBoolean("bubble",false);
	}
	public static void setImagePath(Context context,String isSet){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		sharedPreferences.edit().putString("path",isSet).apply();
	}
	public static String getImagePath(Context context){
		sharedPreferences = context.getSharedPreferences(PREF_,Context.MODE_PRIVATE);
		return sharedPreferences.getString("path",null);
	}

	public static Bitmap getRoundedCroppedBitmap(Bitmap bitmap) {
		int widthLight = bitmap.getWidth();
		int heightLight = bitmap.getHeight();

		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(),
				Bitmap.Config.ARGB_8888);

		Canvas canvas = new Canvas(output);
		Paint paintColor = new Paint();
		paintColor.setFlags(Paint.ANTI_ALIAS_FLAG);

		RectF rectF = new RectF(new Rect(0, 0, widthLight, heightLight));

		canvas.drawRoundRect(rectF, widthLight / 2, heightLight / 2, paintColor);

		Paint paintImage = new Paint();
		paintImage.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
		canvas.drawBitmap(bitmap, 0, 0, paintImage);

		return output;
	}
}
