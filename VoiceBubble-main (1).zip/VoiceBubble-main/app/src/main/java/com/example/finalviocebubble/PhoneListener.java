package com.example.finalviocebubble;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

public class PhoneListener extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, Intent intent) {
        String action = intent.getAction();
        Log.i("HaiNm", "PhoneReceiver: Received unexpected intent: " + action);
        if (!action.equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED) &&
                !action.equals(Intent.ACTION_NEW_OUTGOING_CALL)) {
            Log.e("broadcarrec", "PhoneReceiver: Received unexpected intent: " + action);
            return;
        }

        String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
        String extraState = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

        Log.d("broadcarrec", "PhoneReceiver phone number: " + extraState);


        if (extraState != null) {
            if (extraState.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
               startBubbleAndAudio(context);
               Log.d("PhoneListener","Phone STATE OFFHOOK ");
              /*  Intent myIntent = new Intent(context,
                        RecordService.class);
                myIntent.putExtra("commandType",
                        Constants.STATE_CALL_START);
                context.startService(myIntent);*/
            }
            if (extraState.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                Log.e("callend","yes");
               context.stopService(new Intent(context, ChatHeadService.class));

               /* Intent myIntent = new Intent(context,
                        RecordService.class);
                myIntent.putExtra("commandType",
                        Constants.STATE_CALL_END);
                context.startService(myIntent);*/
                //stopRecording();
            }
        }
    }

    private void record(Context context){
        try{


        int audioSource = MediaRecorder.AudioSource.VOICE_COMMUNICATION;
        int samplingRate = 11025;
        int channelConfig = AudioFormat.CHANNEL_IN_DEFAULT;
        int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
        int bufferSize = AudioRecord.getMinBufferSize(samplingRate,channelConfig,audioFormat);

        short[] buffer = new short[bufferSize/4];
       AudioRecord myRecord = new AudioRecord(audioSource,samplingRate,channelConfig,audioFormat,bufferSize);
        Log.e("recording...","yes");
        myRecord.startRecording();
          Appdata.getInstance().myRecord = myRecord;
        int noAllRead = 0;
        while(Appdata.getInstance().myRecord !=null){
            int bufferResults = myRecord.read(buffer,0,bufferSize/4);
            noAllRead += bufferResults;
            int ii = noAllRead;

            for (int i = 0;i<bufferResults;i++){
                int val = buffer[i];
                Log.e("recording...",val+"");

              //  context.runOnUiThread(()->{
                    // speedView.speedTo(val);
                try {
                    Appdata.getInstance().textView.setText(val+" ");

                }catch (Exception e){

                }

//                    TextView raw_value = findViewById(R.id.sensor_value);
//                    raw_value.setText(String.valueOf(val));
//                    TextView no_read = findViewById(R.id.no_read_val);
//                    no_read.setText(String.valueOf(ii));
              //  });
            }

        }
        }catch (Exception e){
e.printStackTrace();
    }
    }
void stopRecording(){

        try{
            Appdata.getInstance().mThread.stop();
           Appdata.getInstance().myRecord.stop();
        }catch (Exception e){
            Log.e("callend",e.getMessage()+"here");

        } try{
           Appdata.getInstance().myRecord = null;
        }catch (Exception e){
            Log.e("callend",e.getMessage()+"here");

        }
}
    public void startBubbleAndAudio(Context context){
        //if (Utils.canDrawOverlays(Appdata)) {
        Log.d("broadcarrec", "starting ChatHEad" );
        Intent i = new Intent();
        i.setClassName("com.example.finalviocebubble", "com.example.finalviocebubble.MainActivity");
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("fromser","1");
       context.startActivity(i);

        context.startService(new Intent(context, ChatHeadService.class));

        Appdata.getInstance().mThread = new Thread(new Runnable() {
               @Override
               public void run() {
                   //record(context);
               }
           });
        Appdata.getInstance().mThread.start();

    }
}