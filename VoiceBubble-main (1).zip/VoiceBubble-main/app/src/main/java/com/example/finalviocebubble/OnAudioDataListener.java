package com.example.finalviocebubble;

public interface OnAudioDataListener {

    void onAudioDataReceived(int progress);
}
